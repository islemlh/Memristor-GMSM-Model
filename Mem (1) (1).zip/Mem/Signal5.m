function [t,vSignal] = Signal5(fs,f,V)
    %4,2
    Constants
    % P in constants
    t = 0;
    y = 0; 
    for i = 0:1:P-1
    %For Set
         t1 = 0 + i/f:1/fs:(1/(4*f)-1/fs) + i/f;
         y1 = zeros(size(t1));
         x = size(t1);
         for l = 1:1:x(2)
          y1(l) = 0;
         end
    
     
         t2 = (1/(4*f))+i/f:1/fs:(16/(4*f)-1/fs)+i/f;
         y2 = zeros(size(t2));
         x = size(t2);
         for l = 1:1:x(2)
            y2(l) = (1);
         end
        
         
         t3 = (16/(4*f))+i/f:1/fs:(18/(4*f)-1/fs)+i/f;
         y3 = zeros(size(t3));
         x = size(t3);
         for l = 1:1:x(2)
          y3(l) = 0;
         end
         
         t4 = (18/(4*f))+i/f:1/fs:(34/(4*f)-1/fs)+i/f;
         y4 = zeros(size(t4));
         x = size(t4);
         for l = 1:1:x(2)
            y4(l) = (-1);
         end
         
         t = [t, t1, t2, t3, t4];
         y = [y, y1, y2, y3, y4];
    end


     vSignal = V*y;
end
