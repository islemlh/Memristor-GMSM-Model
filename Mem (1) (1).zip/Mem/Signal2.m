function [t,vSignal] = Signal2(fs,f,V)
     %cosinus signal
     Constants
     % P in constants
     t = 0/(4*f):1/fs:P*4/(4*f);
     y = cos(2*pi*f*t);
     vSignal = V*y;
end
