function [tt,vSignalt] = Signal6(fs,f,V)

    Constants
    
    t = 0;
    y = 0; 
    for i = 0:1:P-1
    %For Set
         t1 = 0 + i/f:1/fs:(1/(10*f)-1/fs) + i/f;
         y1 = zeros(size(t1));
         x = size(t1);
         for l = 1:1:x(2)
          y1(l) = 0;
         end
    
     
         t2 = (1/(10*f))+i/f:1/fs:(3/(10*f)-1/fs)+i/f;
         y2 = zeros(size(t2));
         x = size(t2);
         for l = 1:1:x(2)
            y2(l) = -1;
         end
         
         t3 = (3/(10*f))+i/f:1/fs:(10/(10*f)-1/fs)+i/f;
         y3 = zeros(size(t3));
         x = size(t3);
         for l = 1:1:x(2)
            y3(l) = 0;
         end
        
         t = [t, t1, t2, t3];
         y = [y, y1, y2, y3];
    end
    
     vSignal1 = V*y;
     
     t11 = t;
     y11 = y;
     
     figure(61)
     title('Pre');
     plot(t,vSignal1);
     
    t = 0;
    y = 0; 
    for i = 0:1:P-1
    %For Set
         t1 = 0 + i/f:1/fs:(3/(10*f)-1/fs) + i/f;
         y1 = zeros(size(t1));
         x = size(t1);
         for l = 1:1:x(2)
          y1(l) = 0;
         end
    
     
         t2 = (3/(10*f))+i/f:1/fs:(3.5/(10*f)-1/fs)+i/f;
         y2 = zeros(size(t2));
         x = size(t2);
         for l = 1:1:x(2)
            y2(l) = 1;
         end
        
         t3 = (3.5/(10*f))+i/f:1/fs:(10/(10*f)-1/fs)+i/f;
         y3 = zeros(size(t3));
         x = size(t3);
         for l = 1:1:x(2)
            y3(l) = 0;
         end
         
         t = [t, t1, t2, t3];
         y = [y, y1, y2, y3];
    end
    
     vSignal2 = V*y;
     
     t22 = t;
     y22 = y;
     
     
     figure(62)
     title('Post');
     plot(t,vSignal2);
     
     tt = t11;
     vSignalt = y11+y22;

end
