classdef Mem < handle
    
    properties
         n
         nAToNRatio
         tc
         Ga
         Gb
         phi
         schottkeyAlpha
         schottkeyBeta
         schottkeyReverseAlpha
         schottkeyReverseBeta
         vA
         vB
         Nb
         Na
         vT
    end
    
    methods
        
        %Constrocter
        function obj = Mem(n1, nAToNRatio1 , tc1, Ga1, Gb1, phi1, schottkeyAlpha1, schottkeyBeta1, schottkeyReverseAlpha1, schottkeyReverseBeta1, vA1, vB1, vt1)
            obj.n = n1;
            obj.nAToNRatio = nAToNRatio1;
            obj.tc = tc1;
            obj.Ga = Ga1 / obj.n;
            obj.Gb = Gb1 / obj.n;
            obj.phi = phi1;
            obj.schottkeyAlpha = schottkeyAlpha1;
            obj.schottkeyBeta = schottkeyBeta1;
            obj.schottkeyReverseAlpha = schottkeyReverseAlpha1;
            obj.schottkeyReverseBeta = schottkeyReverseBeta1;
            obj.vA = vA1;
            obj.vB = vB1;
            obj.Na = obj.n * obj.nAToNRatio;
            obj.Nb = obj.n - obj.Na;   
            obj.vT = vt1;
        end
        


        %updating the number of Na and Nb 
        function [na, nb]= dG(obj,voltage, dt)      
            Pa = pa(voltage, dt, obj);
            Pb = pb(voltage, dt, obj);
            
            %mean
            ua = obj.Na * Pa;
            ub = obj.Nb * Pb;
            
            %variance
            stdva = sqrt(obj.Na*Pa*Pb);
            stdvb = sqrt(obj.Nb*Pb*Pa);
            
            %normal distibution 
            Gab = stdva * randn + ua;
            Gba = stdvb * randn + ub;
            
            %update number of each mms type
            obj.Nb = obj.Nb + (Gab - Gba);
            obj.Na = obj.Na + (Gba - Gab);
                %obj.Na = obj.n - obj.Nb; 
            
            %correcting if above allowed happend
            if (obj.Nb > obj.n) 
                obj.Nb = obj.n;
            else
                if (obj.Nb < 0)
                obj.Nb = 0;
                end
            end
            if (obj.Na > obj.n) 
                obj.Na = obj.n;
            else
                if (obj.Na < 0)
                obj.Na = 0;
                end
            end
            na = obj.Na;
            nb = obj.Nb;
            obj.nAToNRatio = 1 - obj.Nb / obj.n; %updating the ratio
            
        end
       
        
        
        %get functions start
        function conductance = getConductance(obj) 
            conductance = obj.Nb * obj.Gb + obj.Na * obj.Ga;
        end
        
        function resistance = getResistance(obj)        
            resistance = 1 / getConductance(obj);
        end
        
        function current = getCurrent(obj, voltage)        
            mssCurrent = voltage * getConductance(obj);
            schottkeyCurrent = getDiodeCurrent(obj, voltage);
            current = obj.phi * mssCurrent + (1 - obj.phi) * schottkeyCurrent;
        end
        
        function diodeCurrent = getDiodeCurrent(obj, voltage)        
            diodeCurrent = -obj.schottkeyReverseAlpha *  exp(-1 * obj.schottkeyReverseBeta * voltage) + obj.schottkeyAlpha * (exp(obj.schottkeyBeta * voltage));
        
        end
        
        function alph = getAlpha(dt, obj)
    
             alph = dt/obj.tc;

        end 
        %get functions end
        
        
        %the probability that the MSS will transition from the B state to the A state
        function Pa1 = pa(voltage, dt, obj)

            exponent = -1 * (voltage - obj.vA) / obj.vT;
            alpha = getAlpha(dt, obj);
            Pa1 = alpha / (1.0 + exp(exponent));

            if (Pa1 > 1.0) 
              Pa1 = 1.0;
            else
                if (Pa1 < 0.0)
                 Pa1 = 0.0;
                end
            end
        end 

        %the probability that the MSS will transition from the A state to the B state
        function Pb1 = pb(voltage, dt, obj)

            exponent = -1 * (voltage - obj.vB) / obj.vT;
            alpha = getAlpha(dt, obj);
            Pb1 = alpha * (1.0 - (1.0 / (1.0 + exp(exponent))));

            if (Pb1 > 1.0) 
              Pb1 = 1.0;
            else
                if (Pb1 < 0.0)
                 Pb1 = 0.0;
                end
            end
        end 
        
        
    end 
end
        