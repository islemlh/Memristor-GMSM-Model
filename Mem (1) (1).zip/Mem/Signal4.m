function [t,vSignal] = Signal4(fs,f,V)
    %Loop of Pulses
    Constants
    % P in constants
    t = 0;
    y = 0; 
    for i = 0:1:P-1
    %For Set
         t1 = 0 + i/f:1/fs:(1/(2*f)-1/fs) + i/f;
         y1 = zeros(size(t1));
         x = size(t1);
         for l = 1:1:x(2)
          y1(l) = 0;
         end
    
     
         t2 = (1/(2*f))+i/f:1/fs:(2/(2*f)-1/fs)+i/f;
         y2 = zeros(size(t2));
         x = size(t2);
         for l = 1:1:x(2)
            y2(l) = 1;
         end
        
         t = [t, t1, t2];
         y = [y, y1, y2];
    end


     vSignal = V*y;
end
