% Constants
K = 1.3806503e-23; %Boltzman constant
Q = 1.60217646e-19; %Electron charge
TEMP = 300; %Temp in Kelvin.
BETA = Q / (K * TEMP);
VT = 1/BETA;


f2 = 100; %freqeuncy.
fs2 = 200*f2;
V = 1; %Voltage high, our model needs negative for set and positive for reset.
dt2 = 1/(fs2*f2);%how many sample.
P = 1; %how many times should the signal repeat.


N2 = 100000;
TC2 = 0.0005e-3;
Ga2 = 2.125e-3;
Gb2 = 0.671e-3;
VA2 = 0.27;
VB2 = -0.37;
schottkeyAlpha2 = 0.0;
schottkeyBeta2 = 0.0;
schottkeyReverseAlpha2 = 0.0;
schottkeyReverseBeta2 = 0.0;
phi2 = 1;

%Normal
%nAToNRatio2 = 0.5;

%nA 0 for set. Negative Voltage.
%nA 1 for reset. Positive Voltage.
nAToNRatio2 = 0;





