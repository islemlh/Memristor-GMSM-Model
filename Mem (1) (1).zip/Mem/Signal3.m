function [t,vSignal] = Signal3(fs,f,V)
    %one pulse
     t1 = 0.0:1/fs:1/(2*f);
     y1 = zeros(size(t1));
     x = size(t1);
     for i = 1:1:x(2)
        y1(i) = 1;
     end
    
     
     t2 = 1/(2*f)+1/fs:1/fs:2/(2*f);
     y2 = zeros(size(t2));
     x = size(t2);
     for i = 1:1:x(2)
        y2(i) = 0;
     end
     
     t3 = 2/(2*f)+1/fs:1/fs:3/(2*f);
     y3 = zeros(size(t3));
     x = size(t3);
     for i = 1:1:x(2)
        y3(i) = 0;
     end
     
     
     t4 = 3/(2*f)+1/fs:1/fs:4/(2*f);
     y4 = zeros(size(t4));
     x = size(t4);
     for i = 1:1:x(2)
        y4(i) = 1;
     end
     
     t5 = 5/(2*f)+1/fs:1/fs:6/(2*f);
     y5 = zeros(size(t5));
     x = size(t5);
     for i = 1:1:x(2)
        y5(i) = 0;
     end
     
     t6 = 6/(2*f)+1/fs:1/fs:7/(2*f);
     y6 = zeros(size(t6));
     x = size(t6);
     for i = 1:1:x(2)
        y6(i) = 0;
     end
     
     t7 = 8/(2*f)+1/fs:1/fs:9/(2*f);
     y7 = zeros(size(t7));
     x = size(t7);
     for i = 1:1:x(2)
        y7(i) = 1;
     end
     
     t8 = 9/(2*f)+1/fs:1/fs:10/(2*f);
     y8 = zeros(size(t8));
     x = size(t8);
     for i = 1:1:x(2)
        y8(i) = 0;
     end
     
     
     t = [t1, t2, t3, t4, t5, t6, t7, t8];
     y = [y1, y2, y3, y4, y5, y6, y7, y8];


     vSignal = V*y;
end
