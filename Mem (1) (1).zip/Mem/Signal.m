function [t,vSignal] = Signal(fs,f,V)

     %t1 = 0.0:1/fs:0.025;
     %y1 = t1;

     %t2 = 0.025:1/fs:0.075;
     %y2 = -t2+0.05;

     %t3 = 0.075:1/fs:0.1;
     %y3 = t3-0.1;

     %t = [t1, t2, t3];
     %y = [y1, y2, y3];

     t = 1/(4*f):1/fs:5/(4*f);
     y = sawtooth(2*pi*f*t,1/2);
     vSignal = V*y;
end




