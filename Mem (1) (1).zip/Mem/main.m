Constants

%declaring of the mem
mem1 = Mem(N2, nAToNRatio2 , TC2, Ga2, Gb2, phi2, schottkeyAlpha2, schottkeyBeta2, schottkeyReverseAlpha2, schottkeyReverseBeta2, VA2, VB2, VT);
%declaring arrays
[t,s2] = Signal6(fs2,f2,V);
I = zeros(size(s2));
R = zeros(size(s2));
C = zeros(size(s2));
na = zeros(size(s2));
nb = zeros(size(s2));
x = size(s2);

%Simulation
for i = 1:1:x(2)
    [na(i), nb(i)] = dG(mem1, s2(i), dt2);
    I(i) = getCurrent(mem1, s2(i));
    R(i) = getResistance(mem1);
    C(i) = getConductance(mem1);
end

%plots
figure(4)
plot(t, s2);
title('signal');

figure(6)
plot(t, R);
title('Resistence');

figure(1)
plot(s2,I);
title('V,I(V)');

figure(5)
plot(t,I);
title('I,I(t)');

figure(2)
plot(t,na);
title('t,Na');


figure(3)
plot(t,nb);
title('t,Nb');


pulse = zeros(size(P));
cond= zeros(size(P));
for h = 0:1:P
    pulse(h+1) = h;
    cond(h+1) = C((h)*200+1);
end
figure(7)
plot(pulse, cond);
title('pulse Number, Conductence');
